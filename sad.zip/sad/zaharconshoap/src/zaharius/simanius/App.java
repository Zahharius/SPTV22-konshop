
package zaharius.simanius;

import manager.HistoryManager;
import entity.Customer;
import entity.Product;
import java.util.Arrays;
import java.util.Scanner;
import java.util.stream.IntStream;

import manager.CustomerManager;
import manager.ProductManager;
import tools.InputProtection;
import manager.SaveManager;
import java.util.List;
import manager.DatabaseManager;



public class App {
    private List<Product> products;
    private List<Customer> customers;
    private DatabaseManager databaseManager;
    public int history[];
    
    private final ProductManager productManager;
    private final CustomerManager customerManager;
    private final HistoryManager historyManager;
    private SaveManager saveManager;
    private Scanner scanner;
    
public App(){
    scanner = new Scanner(System.in);
    this.databaseManager = new DatabaseManager();
    this.saveManager = new SaveManager();
    this.customerManager = new CustomerManager(scanner,databaseManager);
    this.productManager = new ProductManager(scanner,databaseManager);
    this.history = new int[0];
            this.historyManager = new HistoryManager(
                                        scanner,
                                        customerManager,
                                        productManager,
                                        databaseManager
                                );
}
    
    private boolean repeat;
    public void run(){
        boolean repeat = true;
   
    do{
        System.out.println("Канселярский уголок Захара");
        System.out.println("0.Выход из программы");
        System.out.println("1.Добавить Товар");
        System.out.println("2.Список товаров");
        System.out.println("3.Добавить покупателя");
        System.out.println("4.Список покупателей");
        System.out.println("5.ПОКУПАЮ");
        System.out.println("6.Сколько денег заработано");
        System.out.println("7.Дать покупателю ЕЩЁ ДЕНЕГ");
        System.out.println("8.Рейтинг товаров");
        System.out.println("9.Рейтинг покупателей");
        System.out.println("10.Редактирование товаров");
        System.out.println("11.Редактирование покупателей");
        System.out.println("Выберите номер задачи: ");  
        int task = InputProtection.intInput(0,11); 
        System.out.printf("Вы выбрали функцию %d, чтобы выйти нажмите \"0\", чтобы продолжить нажмите \"1\": ",task);
        int toCont = InputProtection.intInput(0,1);
        if(toCont ==0 )continue;
        switch (task) {
            case 0:
                repeat = false;
                break;
            case 1:
                System.out.println("1.Добавить Товар");
                productManager.createProduct();
                break;
            case 2:
                System.out.println("2.Список товаров");
                productManager.showprod();
                break;
            case 3:
                System.out.println("3.Добавить покупателя");
                customerManager.createCustomer();
                break;
            case 4:
                System.out.println("4.Список покупателей"); 
                customerManager.custlist();
                break;
            case 5:
                System.out.println("5.ПОКУПАЮ");
                historyManager.Pokypayu();
                break;
            case 6:
                System.out.println("6.Сколько денег заработано");
                int sum = IntStream.of(history).sum();
                System.out.println("Мы заработали = "+ sum+" ДЕНЕГ");
                break;
            case 7:
                customerManager.datdeneg();
                break;
            case 8:
                System.out.println("8.Рейтинг товаров");
                historyManager.prodRating();
                break;
            case 9:
                System.out.println("9.Рейтинг покупателей");
                customerManager.custrat();
                break;
            case 10:
                System.out.println("10. Редактирование товаров"); 
                productManager.changeprod(products);
            break;
            case 11:
                System.out.println("11.Редактирование покупателей");
                customerManager.changecast(customers);
                break;
            default:
                System.out.println("леее ты не то нажал");
        }
        }while(repeat);
        System.out.println("ну давай пока");
    }
    public DatabaseManager getDatabaseManager() {
        return databaseManager;
    } 

}
