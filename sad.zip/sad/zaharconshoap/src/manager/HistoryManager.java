/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package manager;

import entity.Customer;
import entity.History;
import entity.Product;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.stream.Collectors;
import tools.InputProtection;

/**
 *
 * @author admin
 */
public class HistoryManager {

    private final Scanner scanner;
    private final DatabaseManager databaseManager;
    private final ProductManager productManager;
    private final CustomerManager customerManager;

    public HistoryManager(
            Scanner scanner, 
            DatabaseManager databaseManager,
            ProductManager productManager,
            CustomerManager customerManager
    ) {
        this.scanner = scanner;
        this.databaseManager = databaseManager;
    }
        public void prodRating() {
        List<History> histories = getDatabaseManager().getListHistories();
        Map<Product,Integer> mapRatingBook = new HashMap<>();
        for (int i = 0; i < histories.size(); i++) {
            if(mapRatingBook.containsKey(histories.get(i).getProduct())){
                mapRatingBook.put(histories.get(i).getProduct(), mapRatingBook.get(histories.get(i).getProduct())+1);
            }else{
                mapRatingBook.put(histories.get(i).getProduct(),1);
            }
        }
        Map<Product, Integer> sortedMapRatingBook = mapRatingBook.entrySet()
                .stream()
                .sorted(Map.Entry.comparingByValue(Comparator.reverseOrder()))
                .collect(Collectors.toMap(
                        Map.Entry::getKey,
                        Map.Entry::getValue,
                        (e1, e2) -> e1,
                        LinkedHashMap::new
                ));
        int n = 1;
        for (Map.Entry<Product, Integer> entry : sortedMapRatingBook.entrySet()) {
            System.out.printf("%d. %s: %d%n",
                    n,
                    entry.getKey().getName(),
                    entry.getValue()
            );
            n++;
        }
    }
    public DatabaseManager getDatabaseManager() {
        return databaseManager;
    }

    public void Pokypayu() {
        System.out.println("---ТОВАРЫ---");
                productManager.showprod();
                System.out.println("---ПОКУПАТЕЛИ---");
                customerManager.custlist();
                System.out.println("Выберите покупателя: ");
                int numberCust = InputProtection.intInput(1,null); 
                Customer customer = getDatabaseManager().getCustomer((long)numberCust);
                    System.out.println("Выберите товар: ");
                int numberProd = InputProtection.intInput(1,null); 
                    Product product = getDatabaseManager().getProduct((long)numberProd);
                if(customer.getMoney() > 0){
                    customer.setMoney(customer.getMoney()-product.getPrice());
                    product.setRating(product.getRating() + 1);
                    customer.setRating(customer.getRating() + 1);
                    getDatabaseManager().saveProduct(product);
                    getDatabaseManager().saveCustomer(customer);
                }else{
                System.out.println("НЕТ ДЕНЕГ");
                }
    }
}
