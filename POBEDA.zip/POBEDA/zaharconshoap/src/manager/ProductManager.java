
package manager;

import entity.Product;

import java.util.List;
import java.util.Scanner;
import tools.InputProtection;


public class ProductManager {
    private final Scanner scanner;
    private final DatabaseManager databaseManager;
    
    public ProductManager(Scanner scanner, DatabaseManager databaseManager) {
        this.scanner = new Scanner(System.in);
        this.databaseManager = databaseManager;
    }


    public Product createProduct(){
        Product product = new Product();
        System.out.println("Введите название товара: ");
        product.setName(scanner.nextLine());
        System.out.println("Введите цену товара: ");
        product.setPrice(scanner.nextInt());
        scanner.nextLine();
        getDatabaseManager().saveProduct(product);
        return product;
        
    }
    public void changeprod(List<Product> products) {
        showprod();
        System.out.println("Выберите товар: ");
        int numberProd = InputProtection.intInput(1,null); 
        Product product = getDatabaseManager().getProduct((long)numberProd);
        System.out.print("Изменить имя? (y/n): ");
        String letter = scanner.nextLine();
        if(letter.equals("y")){
            System.out.println("Введите новое название товара: ");
            product.setName(scanner.nextLine());
        }
        System.out.print("Изменить цену? (y/n): ");
        String letter2 = scanner.nextLine();
        if(letter.equals("y")){
            System.out.println("Введите новую цену товара: ");
            product.setPrice(scanner.nextInt());
        }
        getDatabaseManager().saveProduct(product);
    }

     public void showprod() {
        System.out.println("----- Products -----");
        List<Product> products = getDatabaseManager().getListProducts();
        for (int i = 0; i < products.size(); i++) {
            System.out.printf("%s. %s%nстоит %s денег%n",
                    i+1,
                    products.get(i).getName(),
                    products.get(i).getPrice()
            );
        }
    }
   
    public DatabaseManager getDatabaseManager() {
        return databaseManager;
    }

  

}
