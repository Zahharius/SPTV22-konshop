package manager;

import entity.Customer;
import entity.History;
import entity.Product;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

/**
 *
 * @author admin
 */
public class DatabaseManager {
    private EntityManager em;

    public DatabaseManager() {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("zaharconshoapPU");
        this.em = emf.createEntityManager();
    }
    public void saveProduct(Product product){
        try {
            em.getTransaction().begin();
            if(product.getId() == null){
                em.persist(product);
            }else{
                em.merge(product);
            }
            em.getTransaction().commit();
        } catch (Exception e) {
            em.getTransaction().rollback();
        }
    }
    public void saveCustomer(Customer customer){
        try {
            em.getTransaction().begin();
            if(customer.getId() == null){
                em.persist(customer);
            }else{
                em.merge(customer);
            }
            em.getTransaction().commit();
        } catch (Exception e) {
            em.getTransaction().rollback();
        }
    }
    public List<Product> getListProducts() {
        return em.createQuery("SELECT product FROM Product product").getResultList();
    }
    public List<Customer> getListCustomers() {
        return em.createQuery("SELECT customer FROM Customer customer").getResultList();
    }
        public Product getProduct(Long id) {
        try {
            return em.find(Product.class, id);
        } catch (Exception e) {
            return null;
        }
    }
         public Customer getCustomer(Long id) {
        try {
            return em.find(Customer.class, id);
        } catch (Exception e) {
            return null;
        }
    }

    List<History> getListHistories() {
       return em.createQuery("SELECT h FROM History h").getResultList();
    }

    void saveHistory(History history) {
         try {
            em.getTransaction().begin();
            if(history.getId() == null){
                em.persist(history);
            }else{
                em.merge(history);
            }
            em.getTransaction().commit();
        } catch (Exception e) {
            em.getTransaction().rollback();
        }
    }
}