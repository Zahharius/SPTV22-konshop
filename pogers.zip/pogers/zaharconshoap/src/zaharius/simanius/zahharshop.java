
package zaharius.simanius;


public class zahharshop {


    public static void main(String[] args) {
        App app = new App();
        app.run();
    }
    
}