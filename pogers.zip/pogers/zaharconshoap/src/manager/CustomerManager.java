
package manager;

import entity.Customer;

import java.util.List;
import java.util.Scanner;
import tools.InputProtection;


public class CustomerManager {
    private static Scanner scanner;
    private final DatabaseManager databaseManager;
    
    public CustomerManager(Scanner scanner, DatabaseManager databaseManager){
        this.scanner = new Scanner(System.in);
        this.databaseManager = databaseManager;
   }
    public Customer createCustomer(){
        Customer customer = new Customer();
        System.out.println("Введите имя покупателя: ");
        customer.setFirstname(scanner.nextLine());
        System.out.println("Введите Фамилию покупателя: ");
        customer.setLastname(scanner.nextLine());
        System.out.println("Сколько денег вы дадите покупателю: ");
        customer.setMoney(scanner.nextInt());
        scanner.nextLine();
        getDatabaseManager().saveCustomer(customer);
        return customer;
        
    }
    public void changecast(List<Customer> customers) {
        custlist();
        System.out.println("Выберите покупателя: ");
        int numberCust = InputProtection.intInput(1,null); 
        Customer customer = getDatabaseManager().getCustomer((long)numberCust);
        System.out.print("Изменить имя? (y/n): ");
        String letter = scanner.nextLine();
        if(letter.equals("y")){
            System.out.println("Введите новое имя: ");
            customer.setFirstname(scanner.nextLine());
        }
        System.out.print("Изменить фамилию? (y/n): ");
        String letter2 = scanner.nextLine();
        if(letter.equals("y")){
            System.out.println("Введите новую фамилию: ");
            customer.setLastname(scanner.nextLine());
        }
        getDatabaseManager().saveCustomer(customer);
    }
    public void custlist() {
        System.out.println("----- Customers -----");
        List<Customer> customers = getDatabaseManager().getListCustomers();
        for (int i = 0; i < customers.size(); i++) {
            System.out.printf("%s. Имя = %s%nФамилия = %s%nДЕНЬГИ = %s%n",
                    i+1,
                    customers.get(i).getFirstname(),
                    customers.get(i).getLastname(),
                    customers.get(i).getMoney()
            );
        }
    }
    

  public DatabaseManager getDatabaseManager() {
        return databaseManager;
    } 

    public void custrat() {
        List<Customer> customers = getDatabaseManager().getListCustomers();
        for (int i = 0; i < customers.size(); i++) {
            System.out.printf("%s. Имя = %s%nФамилия = %s%nПокупал здесь = %s раз%n",
                    i+1,
                    customers.get(i).getFirstname(),
                    customers.get(i).getLastname(),
                    customers.get(i).getRating()
            );
        }
    }

    public void datdeneg() {
    custlist();
    System.out.println("Выберите покупателя: ");
    int numberCust = InputProtection.intInput(1,null); 
    Customer customer = getDatabaseManager().getCustomer((long)numberCust);
    System.out.println("Сколько денег выдать: ");
    int dengi = InputProtection.intInput(1,999); 
    customer.setMoney(customer.getMoney()+dengi);
    getDatabaseManager().saveCustomer(customer);
    }
   
}


 
    
