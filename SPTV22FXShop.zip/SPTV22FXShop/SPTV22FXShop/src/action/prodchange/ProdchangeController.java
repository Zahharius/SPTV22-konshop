/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package action.prodchange;

import entity.Product;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ListCell;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.util.Callback;
import sptv22fxshop.HomeController;

/**
 * FXML Controller class
 *
 * @author admin
 */
public class ProdchangeController implements Initializable {

    private HomeController homeController;
    @FXML private ListView lvProducts;
    private ObservableList<Product> Products;
    @FXML private TextField tfNewName;
    @FXML private TextField tfNewPrice;
    
    @FXML private void clickChange(){
        if(tfNewPrice.getText().isEmpty() || lvProducts.getItems().isEmpty()||tfNewName.getText().isEmpty()){
            homeController.getLbInfo().getStyleClass().clear();
            homeController.getLbInfo().getStyleClass().add("infoError");
            homeController.getLbInfo().setText("НА АХ");
            lvProducts.getItems().clear();
            tfNewPrice.clear();
            tfNewName.clear();
            return;
        }
        for (int i = 0; i < lvProducts.getItems().size() ; i++ ) {
            Product product = (Product) lvProducts.getItems().get(i);
            product.setName(tfNewName.getText());
            product.setPrice(Integer.parseInt(tfNewPrice.getText()));
            try {
            homeController.getApp().getEntityManager().getTransaction().begin();
            homeController.getApp().getEntityManager().merge(product);
            homeController.getApp().getEntityManager().getTransaction().commit();
            lvProducts.getItems().clear();
            tfNewPrice.clear();
            tfNewName.clear();
            homeController.getLbInfo().getStyleClass().clear();
            homeController.getLbInfo().getStyleClass().add("info");
            homeController.getLbInfo().setText("Продукт изменён");
            
        } catch (Exception e) {
            homeController.getLbInfo().getStyleClass().clear();
            homeController.getLbInfo().getStyleClass().add("infoError");
            homeController.getLbInfo().setText("ерор");
        }
            
        }
    }
    
    
    
        @FXML private void clickChooseProduct(){
        List<Product> listProducts = getHomeController().getApp().getEntityManager()
                .createQuery("SELECT a FROM Product a")
                .getResultList();
        this.Products = FXCollections.observableArrayList(listProducts);
        ListView<Product> listViewAuthorsWindow = new ListView<Product>(Products);
        listViewAuthorsWindow.getSelectionModel().setSelectionMode(javafx.scene.control.SelectionMode.MULTIPLE);
        listViewAuthorsWindow.setCellFactory((ListView<Product> products) -> new ListCell<Product>() {
            @Override
            protected void updateItem(Product product, boolean empty) {
                super.updateItem(product, empty);
                if (product != null) {
                    setText(product.getName()+". Цена: "+product.getPrice()+" денег");
                } else {
                    setText(null);
                }
            }
        });
        Stage modalWindows = new Stage();
        // Кнопка для получения выбранных авторов
        Button selectButton = new Button("Выбрать");
        selectButton.setOnAction(event -> {
            ObservableList<Product> selectedAuthors = listViewAuthorsWindow.getSelectionModel().getSelectedItems();
            
            lvProducts.getItems().addAll(selectedAuthors);
            modalWindows.close();
        });
       
        HBox hbButtons = new HBox(selectButton);
        hbButtons.setSpacing(10);
        hbButtons.setAlignment(Pos.CENTER_RIGHT);
        VBox root = new VBox(listViewAuthorsWindow, hbButtons);
        Scene scene = new Scene(root,300, 250);
        modalWindows.setTitle("Список товаров");
        modalWindows.initModality(Modality.WINDOW_MODAL);
        modalWindows.initOwner(homeController.getApp().getPrimaryStage());
        modalWindows.setScene(scene);
        modalWindows.show();
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        lvProducts.setCellFactory(new Callback<ListView<Product>,ListCell<Product>>(){
                @Override
                public ListCell<Product> call(ListView<Product> p) {
                    return new ListCell<Product>(){
                       @Override
                       protected void updateItem(Product product, boolean empty){
                           super.updateItem(product, empty);
                           if(product != null){
                               setText(product.getName()+". Цена: "+product.getPrice()+" денег");
                           }else{
                               setText(null);
                           }
                       }
                    };
                }
            });
    }    
    public void setHomeController(HomeController homeController) {
        this.homeController = homeController;
    }
    public HomeController getHomeController() {
        return homeController;
    }
}
