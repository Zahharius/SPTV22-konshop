/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package products.listproducts;

import entity.Product;
import java.net.URL;
import java.util.Arrays;
import java.util.List;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.ListCell;
import javafx.scene.control.ListView;
import javafx.util.Callback;
import sptv22fxshop.HomeController;

/**
 * FXML Controller class
 *
 * @author user
 */
public class ListproductsController implements Initializable {

    private HomeController homeController;
    private ObservableList<Product> products;
    @FXML private ListView lvListProducts;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    public void setHomeController(HomeController homeController) {
        this.homeController = homeController;
    }

    public void loadProducts() {
     List<Product> listProducts = homeController.getApp().getEntityManager()
                .createQuery("SELECT u FROM Product u")
                .getResultList();
        this.products = FXCollections.observableArrayList(listProducts);
        lvListProducts.getItems().addAll(this.products);
        lvListProducts.setStyle("-fx-border-color: transparent; -fx-background-color: transparent;");
        lvListProducts.setCellFactory(new Callback<ListView<Product>,ListCell<Product>>(){
                @Override
                public ListCell<Product> call(ListView<Product> p) {
                    return new ListCell<Product>(){
                       @Override
                       protected void updateItem(Product product, boolean empty){
                           super.updateItem(product, empty);
                           if(product != null){
                               int index = getIndex();
                               setText((index + 1) + 
                                       ". "+
                                       product.getName()+ " "+
                                       ". Стоит " +
                                       product.getPrice()+
                                       " денег. "
                                       );
                           }else{
                               setText(null);
                           }
                       }
                    };
                }
            });
    }
    
    
}
