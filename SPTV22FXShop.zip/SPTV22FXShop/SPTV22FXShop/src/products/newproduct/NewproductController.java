/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package products.newproduct;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.Initializable;
import sptv22fxshop.HomeController;
import entity.Product;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;

/**
 * FXML Controller class
 *
 * @author user
 */
public class NewproductController implements Initializable {

    private HomeController homeController;
    @FXML private TextField tfTitle;
    @FXML private TextField tfPrice;
    @FXML private Button btAddProduct;
    
    @FXML private void clickAddProduct(){
        if(tfTitle.getText().isEmpty() || tfPrice.getText().isEmpty()){
            homeController.getLbInfo().getStyleClass().clear();
            homeController.getLbInfo().getStyleClass().add("infoError");
            homeController.getLbInfo().setText("Заполните все поля формы");
            return;
        }
        Product product = new Product();
        product.setName(tfTitle.getText());
        product.setPrice(Integer.parseInt(tfPrice.getText()));
        try {
            
            homeController.getApp().getEntityManager().getTransaction().begin();
            homeController.getApp().getEntityManager().persist(product);
            homeController.getApp().getEntityManager().getTransaction().commit();
            tfTitle.setText("");
            tfPrice.setText("");
            homeController.getLbInfo().getStyleClass().clear();
            homeController.getLbInfo().getStyleClass().add("info");
            homeController.getLbInfo().setText("ХЕЛ ЙЕ");
            
        } catch (Exception e) {
            homeController.getLbInfo().getStyleClass().clear();
            homeController.getLbInfo().getStyleClass().add("infoError");
            homeController.getLbInfo().setText("на ах");
        }
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

  public void setHomeController(HomeController homeController) {
        this.homeController = homeController;
    }
}
