/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package products.prodrat;

import entity.History;
import entity.Product;
import java.net.URL;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;
import java.util.stream.Collectors;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.ListCell;
import javafx.scene.control.ListView;
import sptv22fxshop.HomeController;

/**
 * FXML Controller class
 *
 * @author admin
 */
public class ProdratController implements Initializable {
    private List<History> listHistoryes;
    private HomeController homeController;
    @FXML ListView lvRangeProducts;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
    public void setHomeController(HomeController homeController) {
       this.homeController = homeController;
    }
    public void showRatProduct() {
        listHistoryes = homeController.getApp().getEntityManager()
                .createQuery("SELECT h FROM History h")
                .getResultList();
        Map<Product,Integer> mapRangeProd = new HashMap<>();
        for (History history : listHistoryes) {
            if(mapRangeProd.containsKey(history.getProduct())){
                mapRangeProd.put(history.getProduct(), mapRangeProd.get(history.getProduct()) + 1);
            }else{
                mapRangeProd.put(history.getProduct(), 1);
            }
        }
        Map<Product, Integer> sortedMapRatingProd = mapRangeProd.entrySet()
                .stream()
                .sorted(Map.Entry.comparingByValue(Comparator.reverseOrder()))
                .collect(Collectors.toMap(
                        Map.Entry::getKey,
                        Map.Entry::getValue,
                        (e1, e2) -> e1,
                        LinkedHashMap::new
                ));            
        //задача: отобразить отсортированный HashMap<Book,Integer> в ListView lvRangeBooks 
        lvRangeProducts.setItems(FXCollections.observableArrayList(sortedMapRatingProd.entrySet()));
        lvRangeProducts.setCellFactory(param -> new ListCell<Map.Entry>(){
            @Override
            protected void updateItem(Map.Entry entry,boolean empty){
                super.updateItem(entry, empty);
                if(entry==null || empty){
                    setText(null);
                }else{
                    setText(((Product)entry.getKey()).getName()
                                + " купили "
                                + entry.getValue()
                                + " раз(а)");
                }
            }
        });
    }
    
}
