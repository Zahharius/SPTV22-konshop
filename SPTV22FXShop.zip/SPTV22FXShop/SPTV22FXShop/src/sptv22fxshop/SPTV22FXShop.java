/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sptv22fxshop;

import entity.Customer;
import entity.Product;
import javafx.application.Application;
import static javafx.application.Application.launch;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;


/**
 *
 * @author admin
 */
public class SPTV22FXShop extends Application {

    private Stage primaryStage;
    private final EntityManager entityManager;

    public SPTV22FXShop() {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("SPTV22FXShopPU");
        this.entityManager = emf.createEntityManager();
    }
    
    
    @Override
    public void start(Stage primaryStage) throws Exception {
        this.primaryStage = primaryStage;
        this.primaryStage.setTitle("SPTV22FXShop");
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("home.fxml"));
        Parent root = loader.load();
        HomeController homeController = loader.getController();
        homeController.setApp(this);
        Scene scene = new Scene(root);
        scene.getStylesheets().add(getClass().getResource("home.css").toExternalForm());
        primaryStage.setScene(scene);
        primaryStage.show();
    }
    public static void main(String[] args) {
        launch(args);
    }

    public EntityManager getEntityManager() {
        return entityManager;
    }
    public Stage getPrimaryStage() {
        return primaryStage;
    }
}
