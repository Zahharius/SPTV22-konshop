/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sptv22fxshop;


import action.custchange.CustchangeController;
import action.prodchange.ProdchangeController;
import action.purchase.PurchaseController;
import customers.custrat.CustratController;
import customers.listcustomers.ListcustomersController;
import customers.money.MoneyController;
import customers.newcustomer.NewcustomerController;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import javafx.stage.Modality;
import javafx.stage.Stage;
import products.listproducts.ListproductsController;
import products.newproduct.NewproductController;
import products.prodrat.ProdratController;
import sptv22fxshop.SPTV22FXShop;


/**
 *
 * @author admin
 */
public class HomeController implements Initializable {
    private SPTV22FXShop app;
    private Stage loginWindow;
    @FXML private Label lbHello;
    @FXML private Label lbInfo;
    @FXML private VBox vbContent;
    
    
    @FXML
    private void aboutHelp(){
    this.lbHello.setText("Данная программа написана\nстудентом IVKHK группы SPTV22\nЗахаром Симанским");
    }
    
    @FXML
    private void addNewProduct(){
         try {
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("/products/newproduct/newproduct.fxml"));
            VBox vbNewProduct = loader.load();
            NewproductController newproductController = loader.getController();
            newproductController.setHomeController(this);
            app.getPrimaryStage().setTitle("SPTV22FXShop - Добавление нового ПРОДУКТА");
            this.lbInfo.setText("");
            vbContent.getChildren().clear();
            vbContent.getChildren().add(vbNewProduct);
            
        } catch (IOException ex) {
            Logger.getLogger(HomeController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    @FXML
    private void productChange(){
         try {
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("/action/prodchange/prodchange.fxml"));
            VBox vbProdchange = loader.load();
            ProdchangeController prodchangeController = loader.getController();
            prodchangeController.setHomeController(this);
            app.getPrimaryStage().setTitle("SPTV22FXShop - изменение прод укта");
            this.lbInfo.setText("");
            vbContent.getChildren().clear();
            vbContent.getChildren().add(vbProdchange);
            
        } catch (IOException ex) {
            Logger.getLogger(HomeController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    @FXML
    private void customerChange(){
         try {
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("/action/custchange/custchange.fxml"));
            VBox vbCustChange = loader.load();
            CustchangeController custchangeController = loader.getController();
            custchangeController.setHomeController(this);
            app.getPrimaryStage().setTitle("SPTV22FXShop - изменение покупателя");
            this.lbInfo.setText("");
            vbContent.getChildren().clear();
            vbContent.getChildren().add(vbCustChange);
            
        } catch (IOException ex) {
            Logger.getLogger(HomeController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    @FXML
    private void productRating(){
         try {
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("/products/prodrat/prodrat.fxml"));
            VBox vbProdRating = loader.load();
            ProdratController prodratController = loader.getController();
            prodratController.setHomeController(this);
            app.getPrimaryStage().setTitle("SPTV22FXShop - ратинг прод утка");
            this.lbInfo.setText("");
            vbContent.getChildren().clear();
            vbContent.getChildren().add(vbProdRating);
            prodratController.showRatProduct();
            
        } catch (IOException ex) {
            Logger.getLogger(HomeController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    @FXML
    private void customerRating(){
         try {
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("/customers/custrat/custrat.fxml"));
            VBox vbCustRating = loader.load();
            CustratController custratController = loader.getController();
            custratController.setHomeController(this);
            app.getPrimaryStage().setTitle("SPTV22FXShop - ратинг покуп ателя");
            this.lbInfo.setText("");
            vbContent.getChildren().clear();
            vbContent.getChildren().add(vbCustRating);
            custratController.showRatCustomer();
            
        } catch (IOException ex) {
            Logger.getLogger(HomeController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    @FXML
    private void addPurchase(){
         try {
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("/action/purchase/purchase.fxml"));
            VBox vbPurchase = loader.load();
            PurchaseController purchaseController = loader.getController();
            purchaseController.setHomeController(this);
            app.getPrimaryStage().setTitle("SPTV22FXShop - покупаю");
            this.lbInfo.setText("");
            vbContent.getChildren().clear();
            vbContent.getChildren().add(vbPurchase);
            
        } catch (IOException ex) {
            Logger.getLogger(HomeController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    @FXML
    private void addMoney(){
         try {
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("/customers/money/money.fxml"));
            VBox vbMoney = loader.load();
            MoneyController moneyController = loader.getController();
            moneyController.setHomeController(this);
            app.getPrimaryStage().setTitle("SPTV22FXShop - пополнить баланс");
            this.lbInfo.setText("");
            vbContent.getChildren().clear();
            vbContent.getChildren().add(vbMoney);
            
        } catch (IOException ex) {
            Logger.getLogger(HomeController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    @FXML
    private void addNewCustomer(){
         try {
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("/customers/newcustomer/newcustomer.fxml"));
            VBox vbNewCustomer = loader.load();
            NewcustomerController newcustomerController = loader.getController();
            newcustomerController.setHomeController(this);
            app.getPrimaryStage().setTitle("SPTV22FXShop - Добавление нового ПОКУПАТЕЛЯ");
            this.lbInfo.setText("");
            vbContent.getChildren().clear();
            vbContent.getChildren().add(vbNewCustomer);
            
        } catch (IOException ex) {
            Logger.getLogger(HomeController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    @FXML
    private void listProducts(){
         try {
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("/products/listproducts/listproducts.fxml"));
            VBox vbListProducts = loader.load();
            ListproductsController listproductsController = loader.getController();
            listproductsController.setHomeController(this);
            listproductsController.loadProducts();
            app.getPrimaryStage().setTitle("SPTV22FXLibrary - Список продуктов");
            this.lbInfo.setText("");
            vbContent.getChildren().clear();
            vbContent.getChildren().add(vbListProducts);
            
        } catch (IOException ex) {
            Logger.getLogger(HomeController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    

    @FXML 
    private void listCustomers(){
         try {
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("/customers/listcustomers/listcustomers.fxml"));
            VBox vbListCustomers = loader.load();
            ListcustomersController listcustomersController = loader.getController();
            listcustomersController.setHomeController(this);
            listcustomersController.loadCustomers();
            app.getPrimaryStage().setTitle("SPTV22FXLibrary - Список пользователей");
            this.lbInfo.setText("");
            vbContent.getChildren().clear();
            vbContent.getChildren().add(vbListCustomers);
            
        } catch (IOException ex) {
            Logger.getLogger(HomeController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        lbHello.setText("Добро пожаловать в мой магазин!");
       
    }    

    void setApp(SPTV22FXShop app) {
        this.app = app;
    }

    public SPTV22FXShop getApp() {
        return app;
    }

    public Label getLbInfo() {
        return lbInfo;
    }

    public Stage getLoginWindow() {
        return loginWindow;
    }
    
}
