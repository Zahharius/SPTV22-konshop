/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package customers.custrat;

import entity.History;
import entity.Customer;
import java.net.URL;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;
import java.util.stream.Collectors;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.ListCell;
import javafx.scene.control.ListView;
import sptv22fxshop.HomeController;

/**
 * FXML Controller class
 *
 * @author admin
 */
public class CustratController implements Initializable {
    private List<History> listHistoryes;
    private HomeController homeController;
    @FXML ListView lvRangeCustomers;
        
    public void setHomeController(HomeController homeController) {
       this.homeController = homeController;
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
    public void showRatCustomer() {
        listHistoryes = homeController.getApp().getEntityManager()
                .createQuery("SELECT h FROM History h")
                .getResultList();
        Map<Customer,Integer> mapRangeCust = new HashMap<>();
        for (History history : listHistoryes) {
            if(mapRangeCust.containsKey(history.getCustomer())){
                mapRangeCust.put(history.getCustomer(), mapRangeCust.get(history.getCustomer()) + 1);
            }else{
                mapRangeCust.put(history.getCustomer(), 1);
            }
        }
        Map<Customer, Integer> sortedMapRatingCust = mapRangeCust.entrySet()
                .stream()
                .sorted(Map.Entry.comparingByValue(Comparator.reverseOrder()))
                .collect(Collectors.toMap(
                        Map.Entry::getKey,
                        Map.Entry::getValue,
                        (e1, e2) -> e1,
                        LinkedHashMap::new
                ));            

        lvRangeCustomers.setItems(FXCollections.observableArrayList(sortedMapRatingCust.entrySet()));
        lvRangeCustomers.setCellFactory(param -> new ListCell<Map.Entry>(){
            @Override
            protected void updateItem(Map.Entry entry,boolean empty){
                super.updateItem(entry, empty);
                if(entry==null || empty){
                    setText(null);
                }else{
                    setText(((Customer)entry.getKey()).getFirstname()
                                +" "
                                +((Customer)entry.getKey()).getLastname()
                                + " покупал(а) здесь "
                                + entry.getValue()
                                + " раз(а)");
                }
            }
        });
    }
    
}
