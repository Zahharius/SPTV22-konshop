/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package customers.money;

import entity.Customer;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ListCell;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.util.Callback;
import sptv22fxshop.HomeController;

/**
 * FXML Controller class
 *
 * @author admin
 */
public class MoneyController implements Initializable {

    private HomeController homeController;
    @FXML private ListView lvCustomers;
    private ObservableList<Customer> customers;
    @FXML private Button btBablo;
    @FXML private TextField tfBablo;
    


    
    @FXML private void clickBablo(){
        if(tfBablo.getText().isEmpty() || lvCustomers.getItems().isEmpty()){
            homeController.getLbInfo().getStyleClass().clear();
            homeController.getLbInfo().getStyleClass().add("infoError");
            homeController.getLbInfo().setText("НА АХ");
            return;
        }
        for (int i = 0; i < lvCustomers.getItems().size() ; i++ ) {
            Customer customer = (Customer) lvCustomers.getItems().get(i);
            customer.setMoney(customer.getMoney()+Integer.parseInt(tfBablo.getText()));
            try {
            homeController.getApp().getEntityManager().getTransaction().begin();
            homeController.getApp().getEntityManager().merge(customer);
            homeController.getApp().getEntityManager().getTransaction().commit();
            lvCustomers.getItems().clear();
            tfBablo.setText("");
            homeController.getLbInfo().getStyleClass().clear();
            homeController.getLbInfo().getStyleClass().add("info");
            homeController.getLbInfo().setText("ПЛЮС ДЕНЬГИ");
            
        } catch (Exception e) {
            homeController.getLbInfo().getStyleClass().clear();
            homeController.getLbInfo().getStyleClass().add("infoError");
            homeController.getLbInfo().setText("деньги не выданы");
        }
            
        }
    }
    
    
        @FXML private void clickChooseCustomer(){
        List<Customer> listCustomers = getHomeController().getApp().getEntityManager()
                .createQuery("SELECT a FROM Customer a")
                .getResultList();
        this.customers = FXCollections.observableArrayList(listCustomers);
        ListView<Customer> listViewAuthorsWindow = new ListView<Customer>(customers);
        listViewAuthorsWindow.getSelectionModel().setSelectionMode(javafx.scene.control.SelectionMode.MULTIPLE);
        listViewAuthorsWindow.setCellFactory((ListView<Customer> customers) -> new ListCell<Customer>() {
            @Override
            protected void updateItem(Customer customer, boolean empty) {
                super.updateItem(customer, empty);
                if (customer != null) {
                    setText(customer.getFirstname()+" "+customer.getLastname());
                } else {
                    setText(null);
                }
            }
        });
        Stage modalWindows = new Stage();
        // Кнопка для получения выбранных авторов
        Button selectButton = new Button("Выбрать");
        selectButton.setOnAction(event -> {
            ObservableList<Customer> selectedAuthors = listViewAuthorsWindow.getSelectionModel().getSelectedItems();
            
            lvCustomers.getItems().addAll(selectedAuthors);
            modalWindows.close();
        });
       
        HBox hbButtons = new HBox(selectButton);
        hbButtons.setSpacing(10);
        hbButtons.setAlignment(Pos.CENTER_RIGHT);
        VBox root = new VBox(listViewAuthorsWindow, hbButtons);
        Scene scene = new Scene(root,300, 250);
        modalWindows.setTitle("Список покупателей");
        modalWindows.initModality(Modality.WINDOW_MODAL);
        modalWindows.initOwner(homeController.getApp().getPrimaryStage());
        modalWindows.setScene(scene);
        modalWindows.show();
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        lvCustomers.setCellFactory(new Callback<ListView<Customer>,ListCell<Customer>>(){
                @Override
                public ListCell<Customer> call(ListView<Customer> p) {
                    return new ListCell<Customer>(){
                       @Override
                       protected void updateItem(Customer customer, boolean empty){
                           super.updateItem(customer, empty);
                           if(customer != null){
                               setText(customer.getFirstname()+" "+customer.getLastname());
                           }else{
                               setText(null);
                           }
                       }
                    };
                }
            });
    }    
    
    public void setHomeController(HomeController homeController) {
        this.homeController = homeController;
    }
    private void createModalWindows() {
        
    }

    public HomeController getHomeController() {
        return homeController;
    }
}
