/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package customers.newcustomer;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.Initializable;
import sptv22fxshop.HomeController;
import entity.Customer;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import java.util.Random;



/**
 * FXML Controller class
 *
 * @author user
 */
public class NewcustomerController implements Initializable {
    
    private HomeController homeController;
    @FXML private TextField tfFirstName;
    @FXML private TextField tfLastName;
    @FXML private TextField tfMoney;
    @FXML private Button btAddCustomer;
    
    @FXML private void clickAddCustomer(){
        if(tfFirstName.getText().isEmpty() || tfLastName.getText().isEmpty() || tfMoney.getText().isEmpty()){
            homeController.getLbInfo().getStyleClass().clear();
            homeController.getLbInfo().getStyleClass().add("infoError");
            homeController.getLbInfo().setText("Заполните все поля формы");
            return;
        }
        Customer customer = new Customer();
        Random rand = new Random();
        customer.setFirstname(tfFirstName.getText());
        customer.setLastname(tfLastName.getText());
        customer.setMoney(Integer.parseInt(tfMoney.getText()));
        customer.setCode(rand.nextInt(10000));
        try {
            homeController.getApp().getEntityManager().getTransaction().begin();
            homeController.getApp().getEntityManager().persist(customer);
            homeController.getApp().getEntityManager().getTransaction().commit();
            tfFirstName.setText("");
            tfLastName.setText("");
            tfMoney.setText("");
            homeController.getLbInfo().getStyleClass().clear();
            homeController.getLbInfo().getStyleClass().add("info");
            homeController.getLbInfo().setText("покупатель создан");
            
        } catch (Exception e) {
            homeController.getLbInfo().getStyleClass().clear();
            homeController.getLbInfo().getStyleClass().add("infoError");
            homeController.getLbInfo().setText("ошибка критическая");
        }
    
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
     public void setHomeController(HomeController homeController) {
        this.homeController = homeController;
    }
}
