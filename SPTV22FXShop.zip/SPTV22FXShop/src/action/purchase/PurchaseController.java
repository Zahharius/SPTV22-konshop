/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package action.purchase;

import entity.Customer;
import entity.Product;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ListCell;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.util.Callback;
import sptv22fxshop.HomeController;

/**
 * FXML Controller class
 *
 * @author admin
 */
public class PurchaseController implements Initializable {

    private HomeController homeController;
    private ObservableList<Product> products;
    private ObservableList<Customer> customers;
    private VBox vbPurchase;
    @FXML private Button btChooseProduct;
    @FXML private ListView lvProducts;
    @FXML private ListView lvCustomers;
    @FXML private Button btChooseCustomer;
    @FXML private Button btPurch;
    
    @FXML private void clickPurch(){
     List<Product>productPur = new ArrayList<>();
        for (int i = 0; i < lvProducts.getItems().size(); i++) {
            Product product = (Product) lvProducts.getItems().get(i);
           
        }
         
     }
    
    @FXML private void clickChooseCustomer(){
        List<Customer> listCustomers = getHomeController().getApp().getEntityManager()
                .createQuery("SELECT a FROM Customer a")
                .getResultList();
        this.customers = FXCollections.observableArrayList(listCustomers);
        ListView<Customer> listViewAuthorsWindow = new ListView<Customer>(customers);
        listViewAuthorsWindow.getSelectionModel().setSelectionMode(javafx.scene.control.SelectionMode.MULTIPLE);
        listViewAuthorsWindow.setCellFactory((ListView<Customer> customers) -> new ListCell<Customer>() {
            @Override
            protected void updateItem(Customer customer, boolean empty) {
                super.updateItem(customer, empty);
                if (customer != null) {
                    setText(customer.getFirstname()+" "+customer.getLastname());
                } else {
                    setText(null);
                }
            }
        });
        Stage modalWindows = new Stage();
        // Кнопка для получения выбранных авторов
        Button selectButton = new Button("Выбрать");
        selectButton.setOnAction(event -> {
            ObservableList<Customer> selectedAuthors = listViewAuthorsWindow.getSelectionModel().getSelectedItems();
            
            lvCustomers.getItems().addAll(selectedAuthors);
            modalWindows.close();
        });
       
        HBox hbButtons = new HBox(selectButton);
        hbButtons.setSpacing(10);
        hbButtons.setAlignment(Pos.CENTER_RIGHT);
        VBox root = new VBox(listViewAuthorsWindow, hbButtons);
        Scene scene = new Scene(root,300, 250);
        modalWindows.setTitle("Список покупателей");
        modalWindows.initModality(Modality.WINDOW_MODAL);
        modalWindows.initOwner(homeController.getApp().getPrimaryStage());
        modalWindows.setScene(scene);
        modalWindows.show();
    }
    
    @FXML private void clickChooseProduct(){
        List<Product> listProducts = getHomeController().getApp().getEntityManager()
                .createQuery("SELECT a FROM Product a")
                .getResultList();
        this.products = FXCollections.observableArrayList(listProducts);
        ListView<Product> listViewAuthorsWindow = new ListView<Product>(products);
        listViewAuthorsWindow.getSelectionModel().setSelectionMode(javafx.scene.control.SelectionMode.MULTIPLE);
        listViewAuthorsWindow.setCellFactory((ListView<Product> products) -> new ListCell<Product>() {
            @Override
            protected void updateItem(Product product, boolean empty) {
                super.updateItem(product, empty);
                if (product != null) {
                    setText(product.getName());
                } else {
                    setText(null);
                }
            }
        });
        Stage modalWindows = new Stage();
        // Кнопка для получения выбранных авторов
        Button selectButton = new Button("Выбрать");
        selectButton.setOnAction(event -> {
            ObservableList<Product> selectedAuthors = listViewAuthorsWindow.getSelectionModel().getSelectedItems();
            
            lvProducts.getItems().addAll(selectedAuthors);
            modalWindows.close();
        });
       
        HBox hbButtons = new HBox(selectButton);
        hbButtons.setSpacing(10);
        hbButtons.setAlignment(Pos.CENTER_RIGHT);
        VBox root = new VBox(listViewAuthorsWindow, hbButtons);
        Scene scene = new Scene(root,300, 250);
        modalWindows.setTitle("Список товаров");
        modalWindows.initModality(Modality.WINDOW_MODAL);
        modalWindows.initOwner(homeController.getApp().getPrimaryStage());
        modalWindows.setScene(scene);
        modalWindows.show();
    }
   
    @FXML private List<Product> getListProducts(){
        
        return new ArrayList<Product>();
    }
    
    @FXML private List<Customer> getListCustomers(){
        
        return new ArrayList<Customer>();
    }
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        lvProducts.setCellFactory(new Callback<ListView<Product>,ListCell<Product>>(){
                @Override
                public ListCell<Product> call(ListView<Product> p) {
                    return new ListCell<Product>(){
                       @Override
                       protected void updateItem(Product product, boolean empty){
                           super.updateItem(product, empty);
                           if(product != null){
                               setText(product.getName());
                           }else{
                               setText(null);
                           }
                       }
                    };
                }
            });
        lvCustomers.setCellFactory(new Callback<ListView<Customer>,ListCell<Customer>>(){
                @Override
                public ListCell<Customer> call(ListView<Customer> p) {
                    return new ListCell<Customer>(){
                       @Override
                       protected void updateItem(Customer customer, boolean empty){
                           super.updateItem(customer, empty);
                           if(customer != null){
                               setText(customer.getFirstname()+" "+customer.getLastname());
                           }else{
                               setText(null);
                           }
                       }
                    };
                }
            });
    }    

    public void setHomeController(HomeController homeController) {
        this.homeController = homeController;
    }

    private void createModalWindows() {
        
    }

    public HomeController getHomeController() {
        return homeController;
    }
    

}
